export const studentIfo = () => {
  return [
    { title: '学生姓名', type: 'text' }
  ]
}
