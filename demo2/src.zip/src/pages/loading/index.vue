<template>
  <div>
    <button @click="load">loading</button>
  </div>
</template>
<script>
export default {
  name: 'loading',
  data () {
    return {

    }
  },
  methods: {
    load () {
      this.$loading.showLoading({
        info: '加载中'
      })
    }
  }
}
</script>
