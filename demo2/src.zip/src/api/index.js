import { httpPost } from '@/axios/index.js'

export const getList = data => {
  return httpPost('url', data)
}

export const foo = (a, b) => {
  return a + b
}
